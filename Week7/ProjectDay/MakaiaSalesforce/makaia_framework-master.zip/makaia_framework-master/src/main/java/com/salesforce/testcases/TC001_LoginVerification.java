package com.salesforce.testcases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.framework.testng.api.base.ProjectSpecificMethods;
import com.salesforce.pages.LoginPage;

public class TC001_LoginVerification extends ProjectSpecificMethods {
	@BeforeTest
	public void setValues() {
		testcaseName="Verify Login";
		testDescription="Test to verify application is stable and grants access using valid credentials";
		authors="Bhuvanesh";
		category="Smoke";
		excelFileName="Login";
	}
	
	@Test(dataProvider = "fetchData")
	public void runLoginVerification(String userName, String password) {
		LoginPage user = new LoginPage();
		user.enterUserName(userName).enterPassword(password).clickLoginButton();
	}

}
