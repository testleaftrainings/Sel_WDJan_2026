package com.salesforce.pages;

import org.openqa.selenium.WebElement;

import com.framework.selenium.api.base.SeleniumBase;
import com.framework.selenium.api.design.Locators;

public class LoginPage extends SeleniumBase{
	 public LoginPage enterUserName(String uname) {
		 WebElement locatorForUserNameField = locateElement("username");
		 clearAndType(locatorForUserNameField, uname);
		 reportStep("Username is successfully entered as "+uname, "pass");
		 return this;
	}
	public LoginPage enterPassword(String pword) {
		clearAndType(locateElement("password"), pword);
		reportStep("password is successfully entered as "+pword, "pass");	
		return this;
	}
	public HomePage clickLoginButton() {
		WebElement  locatorOfLoginButton= locateElement(Locators.XPATH, "//input[@id='Login']");
		executeTheScript("arguments[0].click()", locatorOfLoginButton);
		reportStep("Login Button is successfully clicked", "pass");	
		return new HomePage();

	}

}
