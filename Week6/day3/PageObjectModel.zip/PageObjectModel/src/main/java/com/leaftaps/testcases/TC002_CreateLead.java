package com.leaftaps.testcases;

import org.testng.annotations.Test;

import com.leaftaps.base.ProjectSpecificMethods;
import com.leaftaps.page.LoginPage;

public class TC002_CreateLead extends ProjectSpecificMethods {
	@Test
	public void runCreateLead() {
		LoginPage user = new LoginPage();
		// user flow inside the application
		user.enterUsername().enterPassword().clickLoginButton().clickCrmsfaLink().clickLeadsLink();
//		user1.clickCrmsfaLink();
//		MyHomePage user2 = new MyHomePage();
//		user2.clickLeadsLink();
		

	}
}
